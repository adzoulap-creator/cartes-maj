const RATIO_POLICE_DEFAUT = 0.07;
const POLICE = "Arial, Roboto, sans-serif";
const OMBRE = "0 0 2px #fff, 0 0 2px #fff, 0 0 4px #fff";
const LARGEUR_EXPORT = 1200;
const PHOTO = { left: "8.426%", top: "30.076%", width: "37.023%", height: "29.53%" };
const CACHET = { left: "9.143%", top: "49.387%", width: "42.92%", height: "19.288%" };

function preparerCachet(src) {
    return new Promise(resolve => {
        const image = new Image();
        image.onload = () => {
            const repli = { src: src, ratio: image.naturalWidth / image.naturalHeight };
            try {
                const echelle = Math.min(1, 400 / Math.max(image.naturalWidth, image.naturalHeight));
                const petit = document.createElement("canvas");
                petit.width = Math.max(1, Math.round(image.naturalWidth * echelle));
                petit.height = Math.max(1, Math.round(image.naturalHeight * echelle));
                const ctxPetit = petit.getContext("2d");
                ctxPetit.drawImage(image, 0, 0, petit.width, petit.height);
                const pixels = ctxPetit.getImageData(0, 0, petit.width, petit.height).data;
                let minX = petit.width, minY = petit.height, maxX = -1, maxY = -1;
                for (let y = 0; y < petit.height; y++) {
                    for (let x = 0; x < petit.width; x++) {
                        if (pixels[(y * petit.width + x) * 4 + 3] > 20) {
                            if (x < minX) minX = x;
                            if (x > maxX) maxX = x;
                            if (y < minY) minY = y;
                            if (y > maxY) maxY = y;
                        }
                    }
                }
                if (maxX < 0) return resolve(repli);
                const sx = Math.floor(minX / echelle);
                const sy = Math.floor(minY / echelle);
                const sw = Math.min(image.naturalWidth - sx, Math.ceil((maxX + 1) / echelle) - sx);
                const sh = Math.min(image.naturalHeight - sy, Math.ceil((maxY + 1) / echelle) - sy);
                const rogne = document.createElement("canvas");
                rogne.width = sw;
                rogne.height = sh;
                rogne.getContext("2d").drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
                resolve({ src: rogne.toDataURL("image/png"), ratio: sw / sh });
            } catch (err) {
                resolve(repli);
            }
        };
        image.onerror = () => resolve(null);
        image.src = src;
    });
}

function makeDraggable(el, apresDeplacement) {
    let offsetX = 0, offsetY = 0, isDragging = false;

    el.addEventListener("mousedown", startDrag);
    el.addEventListener("touchstart", startDrag, { passive: false });

    function startDrag(e) {
        e.preventDefault();
        isDragging = true;
        if (e.type === "mousedown") {
            offsetX = e.clientX - el.offsetLeft;
            offsetY = e.clientY - el.offsetTop;
            document.addEventListener("mousemove", drag);
            document.addEventListener("mouseup", stopDrag);
        } else {
            offsetX = e.touches[0].clientX - el.offsetLeft;
            offsetY = e.touches[0].clientY - el.offsetTop;
            document.addEventListener("touchmove", drag, { passive: false });
            document.addEventListener("touchend", stopDrag);
        }
    }

    function drag(e) {
        if (!isDragging) return;
        let x = e.type === "mousemove" ? e.clientX - offsetX : e.touches[0].clientX - offsetX;
        let y = e.type === "mousemove" ? e.clientY - offsetY : e.touches[0].clientY - offsetY;
        el.style.left = x + "px";
        el.style.top = y + "px";
        if (apresDeplacement) apresDeplacement();
    }

    function stopDrag() {
        isDragging = false;
        document.removeEventListener("mousemove", drag);
        document.removeEventListener("mouseup", stopDrag);
        document.removeEventListener("touchmove", drag);
        document.removeEventListener("touchend", stopDrag);
    }
}

window.addEventListener("load", async () => {
    await ouvrirDB();

    const specimen = await loadData("specimenChoisi");
    const formulaires = await loadData("formulairesTemp") || [];
    const cachetChoisi = await loadData("cachetChoisi");
    const imageCachet = cachetChoisi === undefined || cachetChoisi === null ? "assets/cachet.png" : cachetChoisi;

    if (!specimen) {
        alert("Aucun spécimen sélectionné !");
        return;
    }

    if (!specimen.imageSrc) {
        alert("⚠️ Le spécimen n’a pas d’image !");
        return;
    }

    if (!specimen.champs || specimen.champs.length === 0) {
        alert("❌ Aucune position enregistrée pour les champs !");
        return;
    }

    const container = document.getElementById("generationContainer");
    const largeur = Math.min(450, window.innerWidth - 30);
    const hauteur = largeur * (specimen.ratio || 4 / 3);
    const taillePolice = largeur * RATIO_POLICE_DEFAUT;
    const cachetPret = imageCachet ? await preparerCachet(imageCachet) : null;

    const mapping = {
        "Nom": "nom",
        "Prénom": "prenom",
        "Classe": "classe",
        "Matricule": "matricule",
        "Adresse": "adresse",
        "Téléphone": "telephone",
        "Profil": "profil"
    };

    formulaires.forEach(formData => {
        const carte = document.createElement("div");
        carte.className = "carte";
        carte.style.position = "relative";
        carte.style.width = largeur + "px";
        carte.style.height = hauteur + "px";
        carte.style.backgroundImage = `url(${specimen.imageSrc})`;
        carte.style.backgroundSize = "100% 100%";
        carte.style.backgroundRepeat = "no-repeat";
        carte.style.margin = "20px auto";
        carte.style.border = "2px solid black";

        if (formData.profil) {
            const photo = document.createElement("div");
            photo.style.position = "absolute";
            photo.style.left = PHOTO.left;
            photo.style.top = PHOTO.top;
            photo.style.width = PHOTO.width;
            photo.style.height = PHOTO.height;
            photo.style.backgroundImage = `url(${formData.profil})`;
            photo.style.backgroundSize = "cover";
            photo.style.backgroundPosition = "center";
            photo.style.backgroundRepeat = "no-repeat";
            carte.appendChild(photo);
            makeDraggable(photo);
        }

        const limiteurs = [];
        specimen.champs.forEach(champ => {
            const key = mapping[champ.text];
            if (!key || key === "profil") return;

            const div = document.createElement("div");
            div.textContent = key === "matricule" ? (formData[key] || "") : champ.text + ": " + (formData[key] || "");

            div.style.position = "absolute";
            div.style.left = champ.left;
            div.style.top = champ.top;
            div.style.margin = "0";
            div.style.padding = "0";
            div.style.fontFamily = POLICE;
            div.style.fontSize = taillePolice + "px";
            div.style.fontWeight = "700";
            div.style.lineHeight = "1.2";
            div.style.color = "#000";
            div.style.textShadow = OMBRE;

            div.style.whiteSpace = "normal";
            div.style.width = "max-content";
            div.style.wordBreak = "break-word";
            div.style.lineHeight = "1.1";
            div.className = "champCarte";
            carte.appendChild(div);
            const limiter = () => {
                div.style.maxWidth = Math.max(40, carte.clientWidth * 0.97 - div.offsetLeft) + "px";
            };
            limiteurs.push(limiter);
            makeDraggable(div, limiter);
        });

        if (cachetPret) {
            const boiteL = largeur * parseFloat(CACHET.width) / 100;
            const boiteH = hauteur * parseFloat(CACHET.height) / 100;
            const centreX = largeur * (parseFloat(CACHET.left) + parseFloat(CACHET.width) / 2) / 100;
            const centreY = hauteur * (parseFloat(CACHET.top) + parseFloat(CACHET.height) / 2) / 100;
            let cL = Math.sqrt(boiteL * boiteH * cachetPret.ratio);
            let cH = cL / cachetPret.ratio;
            const reduction = Math.min(1, (largeur * 0.9) / cL, (hauteur * 0.45) / cH);
            cL *= reduction;
            cH *= reduction;
            const cachet = document.createElement("div");
            cachet.style.position = "absolute";
            cachet.style.left = ((centreX - cL / 2) / largeur * 100) + "%";
            cachet.style.top = ((centreY - cH / 2) / hauteur * 100) + "%";
            cachet.style.width = (cL / largeur * 100) + "%";
            cachet.style.height = (cH / hauteur * 100) + "%";
            cachet.style.backgroundImage = `url("${cachetPret.src}")`;
            cachet.style.backgroundSize = "100% 100%";
            cachet.style.backgroundRepeat = "no-repeat";
            cachet.style.backgroundPosition = "center";
            cachet.style.pointerEvents = "none";
            carte.appendChild(cachet);
        }

        const wrapper = document.createElement("div");
        wrapper.className = "carteWrapper";
        wrapper.appendChild(carte);
        container.appendChild(wrapper);
        limiteurs.forEach(f => f());
    });
});

async function carteVersDataUrl(carte) {
    const echelle = Math.min(4, LARGEUR_EXPORT / carte.offsetWidth);
    const canvas = await html2canvas(carte, { backgroundColor: "#ffffff", scale: echelle });
    return canvas.toDataURL("image/jpeg", 0.92);
}

document.getElementById("btnDownloadAll").addEventListener("click", async () => {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (cartes.length === 0) return alert("⚠️ Aucune carte à télécharger !");

    try {
        const liste = [];
        for (let i = 0; i < cartes.length; i++) {
            liste.push({ dataUrl: await carteVersDataUrl(cartes[i]), nom: `Carte_${i + 1}.jpg` });
        }
        await enregistrerPlusieurs(liste);
    } catch (err) {
        console.error("Erreur téléchargement :", err);
        alert("❌ Erreur : " + (err.message || err));
    }
});

async function telechargerCarte(indexCarte) {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (indexCarte < 0 || indexCarte >= cartes.length) return alert("❌ Carte introuvable !");
    try {
        await enregistrerImage(await carteVersDataUrl(cartes[indexCarte]), `Carte_${indexCarte + 1}.jpg`);
    } catch (err) {
        console.error(err);
        alert("❌ Erreur : " + (err.message || err));
    }
}

function sauvegarderPositions() {
    const cartes = document.querySelectorAll(".carte");
    cartes.forEach(carte => {
        const champs = carte.querySelectorAll("div, img");
        champs.forEach(champ => {
            champ.dataset.left = champ.style.left;
            champ.dataset.top = champ.style.top;
        });
    });
}