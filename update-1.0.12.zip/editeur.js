const canvas = document.getElementById("canvasEditeur");
const ctx = canvas.getContext("2d");

const TAILLE_MAX_CANEVAS = 1000;
const LARGEUR_MAX_AFFICHAGE = 350;
const MARGE_OUTILS = 64;
const RATIO_PHOTO = 0.8551;

let source = null;
let luminosite = 100;
let luminositeAvant = 100;
let cadreImage = null;
const ratioCadre = RATIO_PHOTO;
let largeurAffichage = 0;
let hauteurAffichage = 0;
let recadre = null;
let zoneRecadrage = null;
let mode = "repos";
let reperePhoto = null;

const btnRecadrer = document.getElementById("btnRecadrer");
const btnLumiere = document.getElementById("btnLumiere");
const btnCadres = document.getElementById("btnCadres");
const btnAnnuler = document.getElementById("btnAnnuler");
const btnOK = document.getElementById("btnOK");
const panneauLumiere = document.getElementById("panneauLumiere");
const slider = document.getElementById("brightnessSlider");

const enveloppe = document.createElement("div");
canvas.parentNode.insertBefore(enveloppe, canvas);
enveloppe.appendChild(canvas);
enveloppe.style.position = "relative";
enveloppe.style.margin = "12px auto";

function definirMode(nouveau) {
    mode = nouveau;
    const repos = nouveau === "repos";
    btnRecadrer.hidden = !repos;
    btnLumiere.hidden = !repos;
    btnCadres.hidden = !repos;
    panneauLumiere.hidden = nouveau !== "lumiere";
}

function chargerImage(src) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error("Image illisible"));
        image.src = src;
    });
}

function ajusterCanvas() {
    const echelle = Math.min(1, TAILLE_MAX_CANEVAS / Math.max(source.width, source.height));
    canvas.width = Math.round(source.width * echelle);
    canvas.height = Math.round(source.height * echelle);

    largeurAffichage = Math.min(LARGEUR_MAX_AFFICHAGE, window.innerWidth - 24 - MARGE_OUTILS);
    hauteurAffichage = largeurAffichage * canvas.height / canvas.width;

    canvas.style.display = "block";
    canvas.style.margin = "0";
    canvas.style.maxWidth = "none";
    canvas.style.maxHeight = "none";
    canvas.style.width = largeurAffichage + "px";
    canvas.style.height = hauteurAffichage + "px";

    enveloppe.style.width = largeurAffichage + "px";
    enveloppe.style.height = hauteurAffichage + "px";
}

function dessiner() {
    if (!source) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.filter = `brightness(${luminosite}%)`;
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    ctx.filter = "none";
    if (cadreImage) ctx.drawImage(cadreImage, 0, 0, canvas.width, canvas.height);
}

async function definirSource(dataUrl) {
    source = await chargerImage(dataUrl);
    ajusterCanvas();
    dessiner();
}

ouvrirDB().then(async () => {
    const donnee = await loadData("imageOriginale");
    if (donnee) {
        await definirSource(donnee);
        activerRecadrage();
    }
}).catch(err => alert("❌ Erreur : " + (err.message || err)));

slider.addEventListener("input", () => {
    luminosite = slider.value;
    dessiner();
});

function quitterRecadrage() {
    if (recadre) recadre.destroy();
    if (zoneRecadrage) zoneRecadrage.remove();
    recadre = null;
    zoneRecadrage = null;
    reperePhoto = null;
    enveloppe.style.display = "block";
}

function majRepere(donnees) {
    if (!reperePhoto || !donnees || !donnees.width || !donnees.height) return;
    const rapport = donnees.width / donnees.height;
    if (rapport > ratioCadre) {
        const part = (donnees.height * ratioCadre) / donnees.width;
        reperePhoto.style.left = ((1 - part) / 2 * 100) + "%";
        reperePhoto.style.width = (part * 100) + "%";
        reperePhoto.style.top = "0";
        reperePhoto.style.height = "100%";
    } else {
        const part = (donnees.width / ratioCadre) / donnees.height;
        reperePhoto.style.top = ((1 - part) / 2 * 100) + "%";
        reperePhoto.style.height = (part * 100) + "%";
        reperePhoto.style.left = "0";
        reperePhoto.style.width = "100%";
    }
}

function activerRecadrage() {
    if (!source) return;
    quitterRecadrage();
    enveloppe.style.display = "none";

    const hauteurZone = Math.max(300, Math.min(hauteurAffichage * 1.1, window.innerHeight * 0.6));
    zoneRecadrage = document.createElement("div");
    zoneRecadrage.style.width = largeurAffichage + "px";
    zoneRecadrage.style.height = hauteurZone + "px";
    zoneRecadrage.style.margin = "12px auto";

    const image = document.createElement("img");
    image.style.display = "block";
    image.style.maxWidth = "100%";
    image.src = source.src;
    zoneRecadrage.appendChild(image);
    enveloppe.insertAdjacentElement("afterend", zoneRecadrage);

    recadre = new Cropper(image, {
        aspectRatio: NaN,
        viewMode: 1,
        dragMode: "none",
        autoCropArea: 1,
        background: false,
        movable: false,
        zoomable: false,
        zoomOnWheel: false,
        zoomOnTouch: false,
        rotatable: false,
        scalable: false,
        cropBoxMovable: true,
        cropBoxResizable: true,
        toggleDragModeOnDblclick: false,
        ready() {
            const boite = zoneRecadrage && zoneRecadrage.querySelector(".cropper-crop-box");
            if (!boite) return;
            reperePhoto = document.createElement("div");
            reperePhoto.style.position = "absolute";
            reperePhoto.style.boxSizing = "border-box";
            reperePhoto.style.border = "2px solid #ffd400";
            reperePhoto.style.pointerEvents = "none";
            reperePhoto.style.zIndex = "5";
            boite.appendChild(reperePhoto);
            majRepere(recadre.getData());
        },
        crop(evenement) {
            majRepere(evenement.detail);
        }
    });

    definirMode("recadrage");
}

async function appliquerRecadrage() {
    if (!recadre) return;
    const rogne = recadre.getCroppedCanvas({
        maxWidth: TAILLE_MAX_CANEVAS,
        maxHeight: TAILLE_MAX_CANEVAS,
        fillColor: "#fff",
        imageSmoothingQuality: "high"
    });
    if (!rogne) {
        alert("❌ Impossible de recadrer cette image.");
        return;
    }
    const rapport = rogne.width / rogne.height;
    let largeurUtile = rogne.width;
    let hauteurUtile = rogne.height;
    if (rapport > ratioCadre) {
        largeurUtile = Math.round(rogne.height * ratioCadre);
    } else {
        hauteurUtile = Math.round(rogne.width / ratioCadre);
    }
    const final = document.createElement("canvas");
    final.width = largeurUtile;
    final.height = hauteurUtile;
    final.getContext("2d").drawImage(
        rogne,
        Math.round((rogne.width - largeurUtile) / 2),
        Math.round((rogne.height - hauteurUtile) / 2),
        largeurUtile,
        hauteurUtile,
        0,
        0,
        largeurUtile,
        hauteurUtile
    );
    const dataUrl = final.toDataURL("image/jpeg", 0.95);
    quitterRecadrage();
    await saveData("imageOriginale", dataUrl);
    await definirSource(dataUrl);
    definirMode("repos");
}

async function recadrerAuCentre() {
    let largeur = source.width;
    let hauteur = largeur / ratioCadre;
    if (hauteur > source.height) {
        hauteur = source.height;
        largeur = hauteur * ratioCadre;
    }
    const temp = document.createElement("canvas");
    temp.width = Math.round(largeur);
    temp.height = Math.round(hauteur);
    temp.getContext("2d").drawImage(
        source,
        (source.width - largeur) / 2,
        (source.height - hauteur) / 2,
        largeur,
        hauteur,
        0,
        0,
        temp.width,
        temp.height
    );
    const dataUrl = temp.toDataURL("image/jpeg", 0.95);
    await saveData("imageOriginale", dataUrl);
    await definirSource(dataUrl);
}

btnRecadrer.addEventListener("click", activerRecadrage);

btnLumiere.addEventListener("click", () => {
    luminositeAvant = luminosite;
    definirMode("lumiere");
});

function ouvrirModalCadres() { document.getElementById("modalCadres").style.display = "flex"; }
function fermerModalCadres() { document.getElementById("modalCadres").style.display = "none"; }

document.querySelectorAll(".cadreOption").forEach(option => {
    option.addEventListener("click", async () => {
        try {
            cadreImage = await chargerImage(option.src);
            dessiner();
        } catch (err) {
            alert("❌ Erreur : " + (err.message || err));
        }
        fermerModalCadres();
    });
});
btnCadres.addEventListener("click", ouvrirModalCadres);

btnAnnuler.addEventListener("click", () => {
    if (mode === "recadrage") {
        quitterRecadrage();
        definirMode("repos");
    } else if (mode === "lumiere") {
        luminosite = luminositeAvant;
        slider.value = luminosite;
        dessiner();
        definirMode("repos");
    } else {
        window.location.href = "formulaire.html";
    }
});

btnOK.addEventListener("click", async () => {
    if (!source) return;
    try {
        if (mode === "recadrage") {
            await appliquerRecadrage();
            return;
        }
        if (mode === "lumiere") {
            definirMode("repos");
            return;
        }
        if (Math.abs(source.width / source.height - ratioCadre) / ratioCadre > 0.02) {
            await recadrerAuCentre();
        }
        await sauvegarderEtRediriger(canvas);
    } catch (err) {
        alert("❌ Erreur : " + (err.message || err));
    }
});

async function sauvegarderEtRediriger(finalCanvas) {
    await ouvrirDB();

    const dataUrl = finalCanvas.toDataURL("image/jpeg", 0.92);
    const indexInput = parseInt(sessionStorage.getItem("inputActif").split("_")[1], 10) - 1;

    const profilsDef = await loadData("profilsDefinitifs") || [];
    profilsDef[indexInput] = dataUrl;
    await saveData("profilsDefinitifs", profilsDef);
    await saveData("imageOriginale", null);

    sessionStorage.setItem("retourEditeur", "1");
    window.location.href = "formulaire.html";
}
