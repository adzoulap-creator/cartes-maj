const URL_VERSION = "https://adzoulap-creator.github.io/cartes-maj/version.json";

async function notifierPret() {
    if (!estNatif()) return;
    try {
        await appelPlugin('CapacitorUpdater', 'notifyAppReady', {});
    } catch (e) {
        console.warn("notifyAppReady :", e);
    }
}

async function verifierMiseAJour(manuel) {
    if (!estNatif()) {
        if (manuel) alert("Disponible uniquement dans l'application Android.");
        return;
    }
    try {
        const rep = await fetch(URL_VERSION + "?t=" + Date.now(), { cache: "no-store" });
        if (!rep.ok) throw new Error("Serveur de mise à jour inaccessible (" + rep.status + ")");
        const info = await rep.json();

        const cur = await appelPlugin('CapacitorUpdater', 'current', {});
        const actuelle = (cur.bundle && cur.bundle.version) || "builtin";

        if (info.version === actuelle) {
            if (manuel) alert("✅ L'application est déjà à jour (" + actuelle + ").");
            return;
        }

        // Anti-boucle : en automatique, on n'applique une version qu'une seule fois
        let dejaEssaye = null;
        try { dejaEssaye = localStorage.getItem("majAppliquee"); } catch (e) {}
        if (!manuel && dejaEssaye === info.version) return;

        const bundle = await appelPlugin('CapacitorUpdater', 'download', {
            url: info.url,
            version: info.version
        });

        try { localStorage.setItem("majAppliquee", info.version); } catch (e) {}
        await appelPlugin('CapacitorUpdater', 'set', { id: bundle.id }); // recharge l'app
    } catch (e) {
        console.error(e);
        if (manuel) alert("❌ Mise à jour impossible : " + (e.message || e));
    }
}

document.addEventListener("DOMContentLoaded", () => {
    notifierPret();
    verifierMiseAJour(false);
    const btn = document.getElementById("updateBtn");
    if (btn) btn.addEventListener("click", () => verifierMiseAJour(true));
});