
// ======================================================
// ELEMENTS HTML
// ======================================================

const inputFile = document.getElementById('input');
const img = document.getElementById('img');
const btnOk = document.getElementById('btnOk');
const btnTransform = document.getElementById('btnTransform');
const afficherCarteApres = document.querySelector('.afficherCarteApres');
const statusBarSlot = document.getElementById('statusBarSlot');

let recadre = null;
let files = [];
let index = 0;
let croppedImages = [];
let filesData = [];


// ======================================================
// BARRE D'AFFICHAGE DU NOM DE LA CARTE
// ======================================================

const nomCarteDiv = document.createElement('div');

nomCarteDiv.style.textAlign = 'center';
nomCarteDiv.style.fontSize = '18px';
nomCarteDiv.style.fontWeight = 'bold';
nomCarteDiv.style.margin = '15px 0';
nomCarteDiv.style.padding = '10px';
nomCarteDiv.style.border = '2px solid #000';
nomCarteDiv.style.background = '#f5f5f5';

statusBarSlot.appendChild(nomCarteDiv);


// ======================================================
// BOUTONS POUR ATTRIBUER UN NOM
// ======================================================

const btnAssignName = document.createElement('button');

btnAssignName.id = 'btnAssignName';
btnAssignName.textContent = 'Assigner un nom';
btnAssignName.style.display = 'none';
btnAssignName.style.margin = '10px';
btnAssignName.style.padding = '10px 20px';

const btnSkipName = document.createElement('button');

btnSkipName.id = 'btnSkipName';
btnSkipName.textContent = 'Passer sans nom';
btnSkipName.style.display = 'none';
btnSkipName.style.margin = '10px';
btnSkipName.style.padding = '10px 20px';

document.body.insertBefore(btnAssignName, afficherCarteApres);
document.body.insertBefore(btnSkipName, afficherCarteApres);


// ======================================================
// SELECTION MULTIPLE DES IMAGES
// ======================================================

// Démarre le traitement à partir d'une liste [{name, dataUrl}]
async function demarrer(liste) {
    if (!liste || liste.length === 0) return;

    if (liste.length % 2 !== 0) {
        alert("⚠️ Veuillez sélectionner un nombre pair d'images !");
        return;
    }

    files = liste;                          // files[i].name = vrai nom
    filesData = liste.map(f => f.dataUrl);
    index = 0;
    croppedImages = [];
    btnTransform.style.display = 'none';

    afficherImageCourante();
}

// ANDROID : on bloque l'input natif et on ouvre le sélecteur de documents
inputFile.addEventListener('click', async (e) => {
    if (!estNatif()) return;
    e.preventDefault();
    try {
        await demarrer(await choisirImagesMobile());
    } catch (err) {
        if (!/cancel/i.test(err.message || '')) {
            alert("❌ Erreur de sélection : " + err.message);
        }
    }
});

// PC : comportement normal
inputFile.addEventListener('change', async function () {
    const liste = await Promise.all(Array.from(this.files).map(file =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = e => resolve({ name: file.name, dataUrl: e.target.result });
            reader.onerror = () => reject(new Error("Lecture impossible : " + file.name));
            reader.readAsDataURL(file);
        })
    ));
    inputFile.value = "";
    await demarrer(liste);
});


// ======================================================
// AFFICHER L'IMAGE COURANTE POUR LE RECADRAGE
// ======================================================

function afficherImageCourante() {

    const src = filesData[index];

    if (!src) return;

    // Afficher le vrai nom du fichier sélectionné
    nomCarteDiv.textContent =
        `Photo ${index + 1} / ${files.length} — ${files[index].name}`;

    img.src = src;

    img.style.display = 'block';
    img.style.width = '400px';
    img.style.height = '350px';

    btnOk.style.display = 'inline-block';

    btnTransform.style.display = 'none';

    btnAssignName.style.display = 'inline-block';
    btnSkipName.style.display = 'inline-block';

    // Initialiser ou remplacer l'image dans Cropper
    if (!recadre) {

        recadre = new Cropper(img, {
            viewMode: 2
        });

    } else {

        recadre.replace(src);

    }

}


// ======================================================
// SAUVEGARDER L'IMAGE RECADREE
// ======================================================

function saveCroppedImage(name = "") {

    if (!recadre) {

        alert("⚠️ Aucune image prête pour le recadrage.");

        return;
    }

    const canvas = recadre.getCroppedCanvas({
        width: 150,
        height: 200
    });

    if (!canvas) {

        alert("❌ Impossible de recadrer cette image.");

        return;
    }

    const dataURL = canvas.toDataURL('image/png');

    croppedImages.push({
        img: dataURL,
        name: name
    });

    img.style.display = 'none';

    btnAssignName.style.display = 'none';
    btnSkipName.style.display = 'none';

    index++;

    if (index < files.length) {

        afficherImageCourante();

    } else {

        nomCarteDiv.textContent =
            `✅ ${croppedImages.length} photos recadrées avec succès`;

        btnTransform.style.display = 'inline-block';

    }

}


// ======================================================
// BOUTON : ASSIGNER UN NOM
// ======================================================

btnAssignName.addEventListener('click', () => {

    const name = prompt("Entrez le nom pour cette carte :");

    saveCroppedImage(name || "");

});


// ======================================================
// BOUTON : PASSER SANS NOM
// ======================================================

btnSkipName.addEventListener('click', () => {

    saveCroppedImage("");

});


// ======================================================
// CHARGER UNE IMAGE DEPUIS SON DATAURL
// ======================================================

function chargerImage(dataURL) {

    return new Promise((resolve, reject) => {

        const image = new Image();

        image.onload = () => resolve(image);

        image.onerror = () => {
            reject(new Error("Image impossible à charger"));
        };

        image.src = dataURL;

    });

}


// ======================================================
// TRANSFORMER CHAQUE PAIRE EN PLANCHE DE 8 CARTES
// ======================================================

btnTransform.addEventListener('click', async function () {

    if (croppedImages.length === 0 || croppedImages.length % 2 !== 0) {

        alert("⚠️ Les photos recadrées doivent être en nombre pair.");

        return;
    }

    btnTransform.disabled = true;

    try {

        img.style.display = 'none';

        if (recadre) {

            recadre.destroy();
            recadre = null;

        }

        afficherCarteApres.innerHTML = "";

        await ouvrirDB();

        const cardWidth = 150;
        const cardHeight = 200;

        const gap = 10;
        const gapVertical = 35;

        const marginBetweenPairs = 35;
        const bottomPadding = 30;

        const singleBlockWidth =
            4 * cardWidth + 3 * gap;

        const singleBlockHeight =
            2 * cardHeight + gapVertical;


        // Fonction pour dessiner les 8 photos
        const dessinerBloc = (ctx, imageObj, imgData, startY) => {

            for (let row = 0; row < 2; row++) {

                for (let col = 0; col < 4; col++) {

                    const x = col * (cardWidth + gap);

                    const y = startY +
                        row * (cardHeight + gapVertical);

                    ctx.drawImage(
                        imageObj,
                        x,
                        y,
                        cardWidth,
                        cardHeight
                    );

                    // Afficher le nom sous chaque photo
                    if (imgData.name) {

                        ctx.font = "14px Arial";
                        ctx.fillStyle = "#000";
                        ctx.textAlign = "center";

                        ctx.fillText(
                            imgData.name,
                            x + cardWidth / 2,
                            y + cardHeight + 18
                        );

                    }

                }

            }

        };


        // Parcourir les images deux par deux
        for (let i = 0; i < croppedImages.length; i += 2) {

            const img1 = croppedImages[i];
            const img2 = croppedImages[i + 1];

            const canvas = document.createElement('canvas');

            const ctx = canvas.getContext('2d');

            canvas.width = singleBlockWidth;

            canvas.height =
                singleBlockHeight * 2 +
                marginBetweenPairs +
                bottomPadding;


            // Charger les deux images
            const image1 = await chargerImage(img1.img);

            const image2 = await chargerImage(img2.img);


            // Dessiner les deux blocs
            dessinerBloc(ctx, image1, img1, 0);

            dessinerBloc(
                ctx,
                image2,
                img2,
                singleBlockHeight + marginBetweenPairs
            );


            // Afficher le canvas
            canvas.style.display = 'block';
            canvas.style.margin = '20px auto';
            canvas.style.border = '2px solid #000';

            afficherCarteApres.appendChild(canvas);


            // Numéro de la paire
            const numeroPaire = i / 2 + 1;


            // Créer le bouton de téléchargement
            const btnDownload = document.createElement('button');

            btnDownload.textContent =
                `Télécharger la paire ${numeroPaire}`;

            btnDownload.style.display = 'block';
            btnDownload.style.margin = '10px auto 40px auto';
            btnDownload.style.padding = '12px 20px';
            btnDownload.style.fontSize = '16px';
            btnDownload.style.fontWeight = 'bold';
            btnDownload.style.cursor = 'pointer';


            // ==================================================
            // TELECHARGEMENT ET SAUVEGARDE
            // ==================================================
            btnDownload.addEventListener('click', async () => {
                btnDownload.disabled = true;
                try {
                    const dataURL = canvas.toDataURL('image/png');
                    await enregistrerImage(dataURL, `carte_paire_${numeroPaire}.png`);

                    const savedPairs = await loadData("cartesPairs") || [];
                    savedPairs.push({ id: numeroPaire, data: dataURL });
                    await saveData("cartesPairs", savedPairs);
                } catch (erreur) {
                    console.error(erreur);
                    alert("❌ Erreur lors du téléchargement : " + (erreur.message || erreur));
                } finally {
                    btnDownload.disabled = false;
                }
            });


            // Ajouter le bouton à la page
            afficherCarteApres.appendChild(btnDownload);

        }


        // Cacher le bouton de transformation
        btnTransform.style.display = 'none';

        nomCarteDiv.textContent =
            "✅ Transformation terminée !";


    } catch (erreur) {

        console.error("Erreur de transformation :", erreur);

        alert(
            "❌ Erreur lors de la transformation : " +
            erreur.message
        );

    } finally {

        btnTransform.disabled = false;

    }

});
