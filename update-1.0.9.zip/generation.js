const RATIO_POLICE_DEFAUT = 0.06;
const POLICE = "Arial, Roboto, sans-serif";
const OMBRE = "0 0 2px #fff, 0 0 2px #fff, 0 0 4px #fff";
const LARGEUR_EXPORT = 1200;

function makeDraggable(el) {
    let offsetX = 0, offsetY = 0, isDragging = false;

    el.addEventListener("mousedown", startDrag);
    el.addEventListener("touchstart", startDrag, { passive: false });

    function startDrag(e) {
        e.preventDefault();
        isDragging = true;
        if (e.type === "mousedown") {
            offsetX = e.clientX - el.offsetLeft;
            offsetY = e.clientY - el.offsetTop;
            document.addEventListener("mousemove", drag);
            document.addEventListener("mouseup", stopDrag);
        } else {
            offsetX = e.touches[0].clientX - el.offsetLeft;
            offsetY = e.touches[0].clientY - el.offsetTop;
            document.addEventListener("touchmove", drag, { passive: false });
            document.addEventListener("touchend", stopDrag);
        }
    }

    function drag(e) {
        if (!isDragging) return;
        let x = e.type === "mousemove" ? e.clientX - offsetX : e.touches[0].clientX - offsetX;
        let y = e.type === "mousemove" ? e.clientY - offsetY : e.touches[0].clientY - offsetY;
        el.style.left = x + "px";
        el.style.top = y + "px";
    }

    function stopDrag() {
        isDragging = false;
        document.removeEventListener("mousemove", drag);
        document.removeEventListener("mouseup", stopDrag);
        document.removeEventListener("touchmove", drag);
        document.removeEventListener("touchend", stopDrag);
    }
}

window.addEventListener("load", async () => {
    await ouvrirDB();

    const specimen = await loadData("specimenChoisi");
    const formulaires = await loadData("formulairesTemp") || [];

    if (!specimen) {
        alert("Aucun spécimen sélectionné !");
        return;
    }

    if (!specimen.imageSrc) {
        alert("⚠️ Le spécimen n’a pas d’image !");
        return;
    }

    if (!specimen.champs || specimen.champs.length === 0) {
        alert("❌ Aucune position enregistrée pour les champs !");
        return;
    }

    const container = document.getElementById("generationContainer");
    const largeur = Math.min(450, window.innerWidth - 30);
    const hauteur = largeur * (specimen.ratio || 4 / 3);
    const taillePolice = largeur * (specimen.ratioPolice || RATIO_POLICE_DEFAUT);
    const champProfil = specimen.champs.find(c => c.text === "Profil");

    const mapping = {
        "Nom": "nom",
        "Prénom": "prenom",
        "Classe": "classe",
        "Matricule": "matricule",
        "Adresse": "adresse",
        "Téléphone": "telephone",
        "Profil": "profil"
    };

    formulaires.forEach(formData => {
        const carte = document.createElement("div");
        carte.className = "carte";
        carte.style.position = "relative";
        carte.style.width = largeur + "px";
        carte.style.height = hauteur + "px";
        carte.style.backgroundImage = `url(${specimen.imageSrc})`;
        carte.style.backgroundSize = "100% 100%";
        carte.style.backgroundRepeat = "no-repeat";
        carte.style.margin = "20px auto";
        carte.style.border = "2px solid black";

        specimen.champs.forEach(champ => {
            const key = mapping[champ.text];
            if (!key || key === "profil") return;

            const div = document.createElement("div");
            div.textContent = key === "matricule" ? (formData[key] || "") : champ.text + ": " + (formData[key] || "");

            div.style.position = "absolute";
            div.style.left = champ.left;
            div.style.top = champ.top;
            div.style.whiteSpace = "nowrap";
            div.style.margin = "0";
            div.style.padding = "0";
            div.style.fontFamily = POLICE;
            div.style.fontSize = taillePolice + "px";
            div.style.fontWeight = "700";
            div.style.lineHeight = "1.2";
            div.style.color = "#000";
            div.style.textShadow = OMBRE;

            div.dataset.largeurMax = largeur * (98 - parseFloat(champ.left)) / 100;
            div.className = "champCarte";
            carte.appendChild(div);
            makeDraggable(div);
        });

        if (formData.profil) {
            const photo = document.createElement("div");
            photo.style.position = "absolute";
            photo.style.left = champProfil ? champProfil.left : "2.7%";
            photo.style.top = champProfil ? champProfil.top : "25%";
            photo.style.width = champProfil && champProfil.width ? champProfil.width : "33.3%";
            photo.style.height = champProfil && champProfil.height ? champProfil.height : "31.7%";
            photo.style.backgroundImage = `url(${formData.profil})`;
            photo.style.backgroundSize = "cover";
            photo.style.backgroundPosition = "center";
            photo.style.backgroundRepeat = "no-repeat";
            carte.appendChild(photo);
            makeDraggable(photo);
        }

        const cachet = document.createElement("img");
        cachet.src = "assets/cachet.png";
        cachet.style.position = "absolute";
        cachet.style.width = "71.1%";
        cachet.style.top = "41.7%";
        cachet.style.right = "20%";
        cachet.style.pointerEvents = "none";
        carte.appendChild(cachet);

        const wrapper = document.createElement("div");
        wrapper.className = "carteWrapper";
        wrapper.appendChild(carte);
        container.appendChild(wrapper);

        carte.querySelectorAll(".champCarte").forEach(div => {
            ajusterTexte(div, parseFloat(div.dataset.largeurMax), taillePolice * 0.6);
        });
    });
});

function ajusterTexte(div, largeurMax, tailleMin) {
    let taille = parseFloat(div.style.fontSize);
    while (div.offsetWidth > largeurMax && taille > tailleMin) {
        taille -= 0.5;
        div.style.fontSize = taille + "px";
    }
}

async function carteVersDataUrl(carte) {
    const echelle = Math.min(4, LARGEUR_EXPORT / carte.offsetWidth);
    const canvas = await html2canvas(carte, { backgroundColor: "#ffffff", scale: echelle });
    return canvas.toDataURL("image/jpeg", 0.92);
}

document.getElementById("btnDownloadAll").addEventListener("click", async () => {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (cartes.length === 0) return alert("⚠️ Aucune carte à télécharger !");

    try {
        const liste = [];
        for (let i = 0; i < cartes.length; i++) {
            liste.push({ dataUrl: await carteVersDataUrl(cartes[i]), nom: `Carte_${i + 1}.jpg` });
        }
        await enregistrerPlusieurs(liste);
    } catch (err) {
        console.error("Erreur téléchargement :", err);
        alert("❌ Erreur : " + (err.message || err));
    }
});

async function telechargerCarte(indexCarte) {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (indexCarte < 0 || indexCarte >= cartes.length) return alert("❌ Carte introuvable !");
    try {
        await enregistrerImage(await carteVersDataUrl(cartes[indexCarte]), `Carte_${indexCarte + 1}.jpg`);
    } catch (err) {
        console.error(err);
        alert("❌ Erreur : " + (err.message || err));
    }
}

function sauvegarderPositions() {
    const cartes = document.querySelectorAll(".carte");
    cartes.forEach(carte => {
        const champs = carte.querySelectorAll("div, img");
        champs.forEach(champ => {
            champ.dataset.left = champ.style.left;
            champ.dataset.top = champ.style.top;
        });
    });
}