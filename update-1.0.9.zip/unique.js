const RATIO_POLICE = 0.06;
const POLICE = "Arial, Roboto, sans-serif";
const OMBRE = "0 0 2px #fff, 0 0 2px #fff, 0 0 4px #fff";

document.addEventListener("DOMContentLoaded", async () => {
    await ouvrirDB();
    await afficherImage();
    initialiserEvenements();
});

function initialiserEvenements() {
    document.getElementById("btnPlacer").addEventListener("click", () => {
        document.getElementById("checkbox").style.display = "block";
    });

    document.getElementById("btnAppliquer").addEventListener("click", () => {
        placer();
        document.getElementById("btnSauvegarder").style.display = "inline-block";
        document.getElementById("checkbox").style.display = "none";
    });

    document.getElementById("btnSauvegarder").addEventListener("click", () => {
        sauvegarder();
    });
}

function styleTexte(champ, img) {
    champ.style.position = "absolute";
    champ.style.fontFamily = POLICE;
    champ.style.fontSize = (img.clientWidth * RATIO_POLICE) + "px";
    champ.style.fontWeight = "700";
    champ.style.lineHeight = "1.2";
    champ.style.color = "#000";
    champ.style.textShadow = OMBRE;
    champ.style.padding = "0";
    champ.style.margin = "0";
    champ.style.whiteSpace = "nowrap";
    champ.style.background = "rgba(255,255,255,0.3)";
    champ.style.outline = "1px dashed #d00";
    champ.style.touchAction = "none";
    champ.style.cursor = "move";
}

function creerPoignee(boite) {
    const poignee = document.createElement("div");
    poignee.style.position = "absolute";
    poignee.style.right = "-14px";
    poignee.style.bottom = "-14px";
    poignee.style.width = "30px";
    poignee.style.height = "30px";
    poignee.style.boxSizing = "border-box";
    poignee.style.borderRadius = "50%";
    poignee.style.background = "#d00";
    poignee.style.border = "3px solid #fff";
    poignee.style.touchAction = "none";

    function debut(e) {
        e.preventDefault();
        e.stopPropagation();
        const point = e.touches ? e.touches[0] : e;
        const x0 = point.clientX;
        const y0 = point.clientY;
        const largeur0 = boite.offsetWidth;
        const hauteur0 = boite.offsetHeight;

        function bouger(ev) {
            const p = ev.touches ? ev.touches[0] : ev;
            if (ev.cancelable) ev.preventDefault();
            boite.style.width = Math.max(30, largeur0 + p.clientX - x0) + "px";
            boite.style.height = Math.max(30, hauteur0 + p.clientY - y0) + "px";
        }

        function fin() {
            document.removeEventListener("mousemove", bouger);
            document.removeEventListener("mouseup", fin);
            document.removeEventListener("touchmove", bouger);
            document.removeEventListener("touchend", fin);
        }

        document.addEventListener("mousemove", bouger);
        document.addEventListener("mouseup", fin);
        document.addEventListener("touchmove", bouger, { passive: false });
        document.addEventListener("touchend", fin);
    }

    poignee.addEventListener("mousedown", debut);
    poignee.addEventListener("touchstart", debut, { passive: false });
    return poignee;
}

function creerBoitePhoto(boite, img) {
    boite.style.position = "absolute";
    boite.style.boxSizing = "border-box";
    boite.style.left = "8%";
    boite.style.top = "30%";
    boite.style.width = (img.clientWidth * 0.36) + "px";
    boite.style.height = (img.clientHeight * 0.32) + "px";
    boite.style.border = "2px dashed #d00";
    boite.style.background = "rgba(255,0,0,0.25)";
    boite.style.display = "flex";
    boite.style.alignItems = "center";
    boite.style.justifyContent = "center";
    boite.style.touchAction = "none";
    boite.style.cursor = "move";

    const etiquette = document.createElement("span");
    etiquette.textContent = "Photo";
    etiquette.style.color = "#fff";
    etiquette.style.fontFamily = POLICE;
    etiquette.style.fontWeight = "700";
    etiquette.style.fontSize = "16px";
    etiquette.style.textShadow = "0 0 3px #000";
    etiquette.style.pointerEvents = "none";

    boite.appendChild(etiquette);
    boite.appendChild(creerPoignee(boite));
}

function placer() {
    const conteneur = document.getElementById("imageContainer");
    const img = document.getElementById("imageInput");
    const choisis = document.querySelectorAll("#checkbox input[type=checkbox]:checked");

    document.querySelectorAll("#imageContainer .champSpecimen").forEach(c => c.remove());

    choisis.forEach((ligne, index) => {
        const champ = document.createElement("div");
        champ.className = "champSpecimen";
        champ.dataset.field = ligne.value;

        if (ligne.value === "Profil") {
            creerBoitePhoto(champ, img);
        } else {
            champ.textContent = ligne.value;
            styleTexte(champ, img);
            champ.style.left = "5%";
            champ.style.top = (10 + index * 10) + "%";
        }

        conteneur.appendChild(champ);
        makeDraggable(champ);
    });
}

function makeDraggable(el) {
    let offsetX = 0, offsetY = 0, isDragging = false;

    el.addEventListener("mousedown", start);
    el.addEventListener("touchstart", start, { passive: false });

    function start(e) {
        e.preventDefault();
        isDragging = true;

        const point = e.touches ? e.touches[0] : e;
        offsetX = point.clientX - el.offsetLeft;
        offsetY = point.clientY - el.offsetTop;

        document.addEventListener("mousemove", move);
        document.addEventListener("mouseup", stop);
        document.addEventListener("touchmove", move, { passive: false });
        document.addEventListener("touchend", stop);
    }

    function move(e) {
        if (!isDragging) return;

        const parent = el.parentElement;
        const rect = parent.getBoundingClientRect();
        const point = e.touches ? e.touches[0] : e;

        el.style.left = ((point.clientX - offsetX) / rect.width) * 100 + "%";
        el.style.top = ((point.clientY - offsetY) / rect.height) * 100 + "%";
    }

    function stop() {
        isDragging = false;
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", stop);
        document.removeEventListener("touchmove", move);
        document.removeEventListener("touchend", stop);
    }
}

async function sauvegarder() {
    const nom = prompt("Entre un nom pour ce spécimen :");
    if (nom === null) return;

    const img = document.getElementById("imageInput");
    const largeur = img.clientWidth;
    const hauteur = img.clientHeight;
    if (!largeur || !hauteur) {
        alert("❌ L'image n'est pas encore chargée !");
        return;
    }

    const rect = img.getBoundingClientRect();
    const baseX = rect.left + img.clientLeft;
    const baseY = rect.top + img.clientTop;
    const liste = [];

    document.querySelectorAll("#imageContainer .champSpecimen").forEach(c => {
        const r = c.getBoundingClientRect();
        const item = {
            text: c.dataset.field,
            left: (((r.left - baseX) / largeur) * 100).toFixed(3) + "%",
            top: (((r.top - baseY) / hauteur) * 100).toFixed(3) + "%"
        };
        if (c.dataset.field === "Profil") {
            item.width = ((r.width / largeur) * 100).toFixed(3) + "%";
            item.height = ((r.height / hauteur) * 100).toFixed(3) + "%";
        }
        liste.push(item);
    });

    const specimen = {
        id: Date.now(),
        nom: nom,
        imageSrc: await loadData("specimenImage"),
        ratio: hauteur / largeur,
        ratioPolice: RATIO_POLICE,
        champs: liste
    };

    const all = await loadData("allSpecimens") || [];
    all.push(specimen);

    await saveData("allSpecimens", all);
    alert("Spécimen sauvegardé avec succès !");
}

async function afficherImage() {
    const img = document.getElementById("imageInput");
    if (!img) return;

    const savedImg = await loadData("specimenImage");
    if (!savedImg) return;

    const conteneur = document.getElementById("imageContainer");
    conteneur.style.position = "relative";
    conteneur.style.display = "block";
    conteneur.style.width = "100%";
    conteneur.style.maxWidth = "400px";
    conteneur.style.height = "auto";
    conteneur.style.margin = "0 auto";

    img.onload = () => {
        img.style.width = "100%";
        img.style.height = "auto";
        img.style.display = "block";
        img.style.margin = "0";
        img.style.border = "none";
        img.style.boxShadow = "0 0 0 2px #000";
    };

    img.src = savedImg;
}