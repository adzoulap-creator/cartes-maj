ouvrirDB().then(async () => {

  const nombre = await loadData("nombreFormulaires");
  const container = document.getElementById("formulairesContainer");

  if (!nombre) {
    alert("Aucun nombre de formulaires défini !");
    return;
  }

  for (let i = 1; i <= nombre; i++) {
    const form = document.createElement("form");
    form.className = "formulaire";
    form.innerHTML = `
      <h3>Formulaire ${i}</h3>
      <label>Profil :
        <input type="file" name="profil" id="profile_${i}" accept="image/*">
      </label>
      <label>Nom : <input type="text" name="nom"></label><br>
      <label>Prénom : <input type="text" name="prenom"></label><br>
      <label>Classe : <input type="text" name="classe"></label><br>
      <label>Matricule : <input type="text" name="matricule"></label><br>
      <label>Adresse : <input type="text" name="adresse"></label><br>
      <label>Téléphone : <input type="text" name="telephone"></label><br>
      <div class="aperçuProfil" id="aperçu_${i}"></div>
    `;
    container.appendChild(form);
  }

  function lireFichier(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = () => reject(new Error("Lecture impossible"));
      reader.readAsDataURL(file);
    });
  }

  function reduireImage(dataUrl, max) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const ratio = Math.min(1, max / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(image.width * ratio);
        canvas.height = Math.round(image.height * ratio);
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.9));
      };
      image.onerror = () => reject(new Error("Image illisible"));
      image.src = dataUrl;
    });
  }

  function sauvegarderChamps() {
    const sauvegarde = [];
    document.querySelectorAll(".formulaire").forEach(form => {
      const data = {};
      form.querySelectorAll("input").forEach(inp => {
        if (inp.type !== "file") data[inp.name] = inp.value;
      });
      sauvegarde.push(data);
    });
    sessionStorage.setItem("formDataAutoSave", JSON.stringify(sauvegarde));
  }

  const profilsSaved = await loadData("profilsDefinitifs") || [];

  for (let i = 1; i <= nombre; i++) {
    const dataUrl = profilsSaved[i - 1];
    const apercu = document.getElementById("aperçu_" + i);
    if (dataUrl && apercu) {
      apercu.innerHTML = `<img src="${dataUrl}" style="width:120px;border-radius:10px;">`;
    }
  }

  const saved = JSON.parse(sessionStorage.getItem("formDataAutoSave") || "[]");
  if (saved.length > 0) {
    const allForms = document.querySelectorAll(".formulaire");
    saved.forEach((data, index) => {
      const form = allForms[index];
      if (!form) return;
      form.querySelectorAll("input").forEach(inp => {
        if (inp.type !== "file" && data[inp.name]) inp.value = data[inp.name];
      });
    });
  }

  if (sessionStorage.getItem("retourEditeur")) {
    sessionStorage.removeItem("retourEditeur");
    sessionStorage.removeItem("inputActif");
    alert("✅ Profil modifié inséré correctement !");
  }

  document.addEventListener("change", async e => {
    if (!e.target || e.target.type !== "file" || !e.target.id.startsWith("profile_")) return;
    const file = e.target.files[0];
    if (!file) return;
    try {
      const brut = await lireFichier(file);
      const reduite = await reduireImage(brut, 1200);
      await saveData("imageOriginale", reduite);
      sessionStorage.setItem("inputActif", e.target.id);
      sauvegarderChamps();
      window.location.href = "editeur.html";
    } catch (err) {
      alert("❌ Erreur : " + (err.message || err));
    }
  });

  document.getElementById("creerCartesBtn").addEventListener("click", async () => {
    const data = await loadData("allSpecimens") || [];
    if (data.length === 0) { alert("Aucun spécimen disponible !"); return; }

    let liste = "Choisis un spécimen :\n";
    data.forEach((sp, i) => liste += `${i + 1}. ${sp.nom}\n`);
    const reponse = prompt(liste);
    if (reponse === null) return;
    const choix = parseInt(reponse, 10) - 1;
    if (isNaN(choix) || choix < 0 || choix >= data.length) { alert("Choix invalide !"); return; }

    const specimen = data[choix];
    const profilsDB = await loadData("profilsDefinitifs") || [];
    const formulaires = [];

    document.querySelectorAll(".formulaire").forEach((f, index) => {
      const formData = {};
      f.querySelectorAll("input").forEach(inp => {
        if (inp.type === "file") {
          formData[inp.name] = profilsDB[index] || null;
        } else {
          formData[inp.name] = inp.value;
        }
      });
      formulaires.push(formData);
    });

    try {
      await saveData("formulairesTemp", formulaires);
      await saveData("specimenChoisi", specimen);
      window.location.href = "generation.html";
    } catch (err) {
      alert("❌ Erreur : " + (err.message || err));
    }
  });

  document.addEventListener("input", sauvegarderChamps);

  document.getElementById("btnReset").addEventListener("click", async () => {
    if (confirm("Voulez-vous vraiment créer un nouveau formulaire ? Tous les profils et champs seront supprimés.")) {
      await saveData("profilsDefinitifs", []);
      await saveData("imageOriginale", null);
      sessionStorage.removeItem("formDataAutoSave");
      sessionStorage.removeItem("inputActif");
      await saveData("formulairesTemp", []);
      await saveData("nombreFormulaires", null);
      window.location.href = "index.html";
    }
  });

});