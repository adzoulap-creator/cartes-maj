const canvas = document.getElementById("canvasEditeur");
const ctx = canvas.getContext("2d");

const TAILLE_MAX_CANEVAS = 1000;
const LARGEUR_MAX_AFFICHAGE = 350;
const RATIO_PHOTO = 0.8551;

let source = null;
let luminosite = 100;
let cadreImage = null;
const ratioCadre = RATIO_PHOTO;
let largeurAffichage = 0;
let hauteurAffichage = 0;
let recadre = null;
let zoneRecadrage = null;
let barreRecadrage = null;

const enveloppe = document.createElement("div");
canvas.parentNode.insertBefore(enveloppe, canvas);
enveloppe.appendChild(canvas);
enveloppe.style.position = "relative";
enveloppe.style.margin = "12px auto";

function chargerImage(src) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error("Image illisible"));
        image.src = src;
    });
}

function ajusterCanvas() {
    const echelle = Math.min(1, TAILLE_MAX_CANEVAS / Math.max(source.width, source.height));
    canvas.width = Math.round(source.width * echelle);
    canvas.height = Math.round(source.height * echelle);

    largeurAffichage = Math.min(LARGEUR_MAX_AFFICHAGE, window.innerWidth - 24);
    hauteurAffichage = largeurAffichage * canvas.height / canvas.width;

    canvas.style.display = "block";
    canvas.style.margin = "0";
    canvas.style.maxWidth = "none";
    canvas.style.maxHeight = "none";
    canvas.style.width = largeurAffichage + "px";
    canvas.style.height = hauteurAffichage + "px";

    enveloppe.style.width = largeurAffichage + "px";
    enveloppe.style.height = hauteurAffichage + "px";
}

function dessiner() {
    if (!source) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.filter = `brightness(${luminosite}%)`;
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    ctx.filter = "none";
    if (cadreImage) ctx.drawImage(cadreImage, 0, 0, canvas.width, canvas.height);
}

async function definirSource(dataUrl) {
    source = await chargerImage(dataUrl);
    ajusterCanvas();
    dessiner();
}

ouvrirDB().then(async () => {
    const donnee = await loadData("imageOriginale");
    if (donnee) {
        await definirSource(donnee);
        activerRecadrage();
    }
}).catch(err => alert("❌ Erreur : " + (err.message || err)));

window.addEventListener("load", () => {
    const menu = document.getElementById("menuGauche");
    setTimeout(() => menu.classList.add("active"), 300);
});

const slider = document.getElementById("brightnessSlider");
slider.addEventListener("input", () => {
    luminosite = slider.value;
    dessiner();
});

function quitterRecadrage() {
    if (recadre) recadre.destroy();
    if (zoneRecadrage) zoneRecadrage.remove();
    if (barreRecadrage) barreRecadrage.remove();
    recadre = null;
    zoneRecadrage = null;
    barreRecadrage = null;
    enveloppe.style.display = "block";
}

function creerBouton(texte, couleur, icone, action) {
    const bouton = document.createElement("button");
    bouton.type = "button";
    bouton.className = "pill " + couleur + " pill--sm";
    bouton.innerHTML = '<span class="pill-icon ' + icone + '"></span><span class="pill-label">' + texte + "</span>";
    bouton.addEventListener("click", action);
    return bouton;
}

function activerRecadrage() {
    if (!source) return;
    quitterRecadrage();
    enveloppe.style.display = "none";

    const hauteurZone = Math.max(240, Math.min(hauteurAffichage, window.innerHeight * 0.55));
    zoneRecadrage = document.createElement("div");
    zoneRecadrage.style.width = largeurAffichage + "px";
    zoneRecadrage.style.height = hauteurZone + "px";
    zoneRecadrage.style.margin = "12px auto";

    const image = document.createElement("img");
    image.style.display = "block";
    image.style.maxWidth = "100%";
    image.src = source.src;
    zoneRecadrage.appendChild(image);
    enveloppe.insertAdjacentElement("afterend", zoneRecadrage);

    barreRecadrage = document.createElement("div");
    barreRecadrage.style.display = "flex";
    barreRecadrage.style.justifyContent = "center";
    barreRecadrage.style.gap = "10px";
    barreRecadrage.style.margin = "8px auto";
    barreRecadrage.appendChild(creerBouton("Annuler recadrage", "pill--red", "ic-x", quitterRecadrage));
    barreRecadrage.appendChild(creerBouton("Valider recadrage", "pill--blue", "ic-check", () => appliquerRecadrage()));
    zoneRecadrage.insertAdjacentElement("afterend", barreRecadrage);

    recadre = new Cropper(image, {
        aspectRatio: ratioCadre,
        viewMode: 2,
        autoCropArea: 0.8,
        background: false
    });
}

async function appliquerRecadrage() {
    if (!recadre) return;
    const rogne = recadre.getCroppedCanvas({
        maxWidth: TAILLE_MAX_CANEVAS,
        maxHeight: TAILLE_MAX_CANEVAS,
        fillColor: "#fff",
        imageSmoothingQuality: "high"
    });
    if (!rogne) {
        alert("❌ Impossible de recadrer cette image.");
        return;
    }
    const dataUrl = rogne.toDataURL("image/jpeg", 0.95);
    quitterRecadrage();
    await saveData("imageOriginale", dataUrl);
    await definirSource(dataUrl);
}

async function recadrerAuCentre() {
    let largeur = source.width;
    let hauteur = largeur / ratioCadre;
    if (hauteur > source.height) {
        hauteur = source.height;
        largeur = hauteur * ratioCadre;
    }
    const temp = document.createElement("canvas");
    temp.width = Math.round(largeur);
    temp.height = Math.round(hauteur);
    temp.getContext("2d").drawImage(
        source,
        (source.width - largeur) / 2,
        (source.height - hauteur) / 2,
        largeur,
        hauteur,
        0,
        0,
        temp.width,
        temp.height
    );
    const dataUrl = temp.toDataURL("image/jpeg", 0.95);
    await saveData("imageOriginale", dataUrl);
    await definirSource(dataUrl);
}

document.getElementById("btnRecadrer").addEventListener("click", activerRecadrage);

function ouvrirModalCadres() { document.getElementById("modalCadres").style.display = "flex"; }
function fermerModalCadres() { document.getElementById("modalCadres").style.display = "none"; }

document.querySelectorAll(".cadreOption").forEach(option => {
    option.addEventListener("click", async () => {
        try {
            cadreImage = await chargerImage(option.src);
            dessiner();
        } catch (err) {
            alert("❌ Erreur : " + (err.message || err));
        }
        fermerModalCadres();
    });
});
document.getElementById("btnCadres").addEventListener("click", ouvrirModalCadres);

document.getElementById("btnOK").addEventListener("click", async () => {
    if (!source) return;
    try {
        if (recadre) {
            await appliquerRecadrage();
        } else if (Math.abs(source.width / source.height - ratioCadre) / ratioCadre > 0.02) {
            await recadrerAuCentre();
        }
        await sauvegarderEtRediriger(canvas);
    } catch (err) {
        alert("❌ Erreur : " + (err.message || err));
    }
});

async function sauvegarderEtRediriger(finalCanvas) {
    await ouvrirDB();

    const dataUrl = finalCanvas.toDataURL("image/jpeg", 0.92);
    const indexInput = parseInt(sessionStorage.getItem("inputActif").split("_")[1], 10) - 1;

    const profilsDef = await loadData("profilsDefinitifs") || [];
    profilsDef[indexInput] = dataUrl;
    await saveData("profilsDefinitifs", profilsDef);
    await saveData("imageOriginale", null);

    sessionStorage.setItem("retourEditeur", "1");
    window.location.href = "formulaire.html";
}

document.getElementById("btnAnnuler").addEventListener("click", () => {
    window.location.href = "formulaire.html";
});
