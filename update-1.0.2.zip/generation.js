// --- 3️⃣ Draggable inchangé ---
function makeDraggable(el) {
    let offsetX = 0, offsetY = 0, isDragging = false;

    el.addEventListener("mousedown", startDrag);
    el.addEventListener("touchstart", startDrag, { passive: false });

    function startDrag(e) {
        e.preventDefault();
        isDragging = true;
        if (e.type === "mousedown") {
            offsetX = e.clientX - el.offsetLeft;
            offsetY = e.clientY - el.offsetTop;
            document.addEventListener("mousemove", drag);
            document.addEventListener("mouseup", stopDrag);
        } else {
            offsetX = e.touches[0].clientX - el.offsetLeft;
            offsetY = e.touches[0].clientY - el.offsetTop;
            document.addEventListener("touchmove", drag, { passive: false });
            document.addEventListener("touchend", stopDrag);
        }
    }

    function drag(e) {
        if (!isDragging) return;
        let x = e.type === "mousemove" ? e.clientX - offsetX : e.touches[0].clientX - offsetX;
        let y = e.type === "mousemove" ? e.clientY - offsetY : e.touches[0].clientY - offsetY;
        el.style.left = x + "px";
        el.style.top = y + "px";
    }

    function stopDrag() {
        isDragging = false;
        document.removeEventListener("mousemove", drag);
        document.removeEventListener("mouseup", stopDrag);
        document.removeEventListener("touchmove", drag);
        document.removeEventListener("touchend", stopDrag);
    }
}

// --- 4️⃣ Génération des cartes avec IndexedDB ---
window.addEventListener("load", async () => {
    await ouvrirDB();

    const specimen = await loadData("specimenChoisi");
    const formulaires = await loadData("formulairesTemp");

    if (!specimen) {
        alert("Aucun spécimen sélectionné !");
        return;
    }

    if (!specimen.imageSrc) {
        alert("⚠️ Le spécimen n’a pas d’image !");
        return;
    }

    if (!specimen.champs || specimen.champs.length === 0) {
        alert("❌ Aucune position enregistrée pour les champs !");
        return;
    }

    const container = document.getElementById("generationContainer");

    formulaires.forEach((formData, index) => {
        const carte = document.createElement("div");
        carte.className = "carte";

        carte.style.position = "relative";
        carte.style.width = "450px";
        carte.style.height = "600px";
        carte.style.backgroundImage = `url(${specimen.imageSrc})`;
        carte.style.backgroundSize = "cover";
        carte.style.margin = "20px auto";
        carte.style.border = "2px solid black";

        const mapping = {
            "Nom": "nom",
            "Prénom": "prenom",
            "Classe": "classe",
            "Matricule": "matricule",
            "Adresse": "adresse",
            "Téléphone": "telephone",
            "Profil": "profil"
        };

        specimen.champs.forEach(champ => {
            const key = mapping[champ.text];
            if (!key || key === "profil") return;

            const div = document.createElement("div");
            div.textContent = key === "matricule" ? (formData[key] || "") : champ.text + ": " + (formData[key] || "");

            div.style.position = "absolute";
            div.style.left = champ.left;
            div.style.top = champ.top;
            div.style.color = "black";
            div.style.fontSize = "26px";
            div.style.fontWeight = "normal";
            div.style.webkitTextStroke = "0.5px white";
            div.style.fontFamily = "Segoe UI, Arial, sans-serif";

            carte.appendChild(div);
            makeDraggable(div);
        });

        if (formData.profil) {
            const img = document.createElement("img");
            img.src = formData.profil;
            img.style.position = "absolute";
            img.style.width = "150px";
            img.style.height = "190px";
            img.style.objectFit = "cover";
            img.style.left = "12px";
            img.style.top = "150px";
            carte.appendChild(img);
            makeDraggable(img);
        }

                // --- Ajouter le cachet sous le profil ---
        const cachet = document.createElement("img");
        cachet.src = "assets/cachet.png";  // chemin de ton cachet

        cachet.style.position = "absolute";

        // Placer juste en dessous de la photo
        cachet.style.width = "320px";  
        cachet.style.top = "250px";
        cachet.style.right = "90px";


        cachet.style.pointerEvents = "none"; // non déplaçable

        carte.appendChild(cachet);

        const wrapper = document.createElement("div");
        wrapper.className = "carteWrapper";
        wrapper.appendChild(carte);
        container.appendChild(wrapper);
    });
});


// --- 5️⃣ Téléchargement des cartes ---
async function carteVersDataUrl(carte) {
    const canvas = await html2canvas(carte);
    return canvas.toDataURL("image/png");
}

document.getElementById("btnDownloadAll").addEventListener("click", async () => {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (cartes.length === 0) return alert("⚠️ Aucune carte à télécharger !");

    try {
        const liste = [];
        for (let i = 0; i < cartes.length; i++) {
            liste.push({ dataUrl: await carteVersDataUrl(cartes[i]), nom: `Carte_${i + 1}.png` });
        }
        await enregistrerPlusieurs(liste);
    } catch (err) {
        console.error("Erreur téléchargement :", err);
        alert("❌ Erreur : " + (err.message || err));
    }
});

async function telechargerCarte(indexCarte) {
    const cartes = document.querySelectorAll("#generationContainer .carte");
    if (indexCarte < 0 || indexCarte >= cartes.length) return alert("❌ Carte introuvable !");
    try {
        await enregistrerImage(await carteVersDataUrl(cartes[indexCarte]), `Carte_${indexCarte + 1}.png`);
    } catch (err) {
        console.error(err);
        alert("❌ Erreur : " + (err.message || err));
    }
}

// --- 6️⃣ Sauvegarde positions inchangé ---
function sauvegarderPositions() {
    const cartes = document.querySelectorAll(".carte");
    cartes.forEach((carte, indexCarte) => {
        const champs = carte.querySelectorAll("div, img");
        champs.forEach(champ => {
            champ.dataset.left = champ.style.left;
            champ.dataset.top = champ.style.top;
        });
    });
}