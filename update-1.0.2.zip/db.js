let db;

function ouvrirDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open("MonAppDB", 1);

        request.onupgradeneeded = function(event) {
            db = event.target.result;
            if (!db.objectStoreNames.contains("donnees")) {
                db.createObjectStore("donnees", { keyPath: "id" });
            }
        };

        request.onsuccess = function(event) {
            db = event.target.result;
            resolve();
        };

        request.onerror = function() {
            reject("Erreur lors de l'ouverture de la base IndexedDB");
        };
    });
}

function saveData(id, valeur) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(["donnees"], "readwrite");
        const store = transaction.objectStore("donnees");
        store.put({ id: id, valeur: valeur });
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject("Erreur lors de la sauvegarde");
    });
}

function loadData(id) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(["donnees"], "readonly");
        const store = transaction.objectStore("donnees");
        const request = store.get(id);
        request.onsuccess = () => resolve(request.result ? request.result.valeur : null);
        request.onerror = () => reject("Erreur lors du chargement");
    });
}

function clearAllData() {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(["donnees"], "readwrite");
        const store = transaction.objectStore("donnees");
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject("Erreur lors de la suppression");
    });
}