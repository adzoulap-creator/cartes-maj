// --- 3️⃣ Initialisation DB ---
ouvrirDB().then(() => {

    // --- Bouton création specimen ---
    const btnSpecimen = document.getElementById("btnCreationSpecimen");
    if (btnSpecimen) {
        btnSpecimen.addEventListener("click", () => {
            const input = document.createElement("input");
            input.type = "file";
            input.accept = "image/*";
            input.style.display = "none";

            input.addEventListener("change", (event) => {
                const file = event.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = async (e) => {
                    await saveData("specimenImage", e.target.result);
                    await loadData("specimenImage"); // force IndexedDB à finaliser l'écriture
                    window.location.href = "specimen.html";
                };
                reader.readAsDataURL(file);
            });

            document.body.appendChild(input);
            input.click();
        });
    }

    // --- Bouton générer formulaire ---
    document.getElementById("genererFormBtn").addEventListener("click", () => {
        const nombre = prompt("Combien de formulaires veux-tu créer ?");
        if (!nombre || isNaN(nombre) || nombre <= 0) {
            alert("Entre un nombre valide !");
            return;
        }

        saveData("nombreFormulaires", nombre).then(() => {
            window.location.href = "formulaire.html";
        });
    });

    // --- Bouton clear storage ---
    document.getElementById("btnClearStorage").addEventListener("click", () => {
        if (confirm("⚠️ Voulez-vous vraiment réinitialiser l’application ?\nTous les spécimens et formulaires seront effacés !")) {
            Promise.all([
                clearAllData(),
                sessionStorage.clear()
            ]).then(() => {
                alert("✔️ Tous les données ont été supprimées !");
                location.reload();
            });
        }
    });

});