// --- 3️⃣ Initialisation DB ---
ouvrirDB().then(async () => {

  /*****************************************************
   * 1️⃣ Génération des formulaires dynamiques
   *****************************************************/
  const nombre = await loadData("nombreFormulaires");
  const container = document.getElementById("formulairesContainer");

  if (!nombre) {
    alert("Aucun nombre de formulaires défini !");
    return;
  }

  for (let i = 1; i <= nombre; i++) {
    const form = document.createElement("form");
    form.className = "formulaire";
    form.innerHTML = `
      <h3>Formulaire ${i}</h3>
      <label>Profil :
        <input type="file" name="profil" id="profile_${i}" accept="image/*">
      </label>
      <label>Nom : <input type="text" name="nom"></label><br>
      <label>Prénom : <input type="text" name="prenom"></label><br>
      <label>Classe : <input type="text" name="classe"></label><br>
      <label>Matricule : <input type="text" name="matricule"></label><br>
      <label>Adresse : <input type="text" name="adresse"></label><br>
      <label>Téléphone : <input type="text" name="telephone"></label><br>
      <div class="aperçuProfil" id="aperçu_${i}"></div>
    `;
    container.appendChild(form);
  }

  // --- RESTAURATION DES PROFILS (session ou IndexedDB) ---
  (async function restoreProfilesAfterGeneration() {
    const savedSession = JSON.parse(sessionStorage.getItem('profilsModifies') || '[]');
    const savedLocal = await loadData('profilsDefinitifs') || [];

    for (let i = 1; i <= nombre; i++) {
      const apercu = document.getElementById('aperçu_' + i);
      const input = document.getElementById('profile_' + i);
      const dataUrl = savedSession[i - 1] || savedLocal[i - 1];

      if (dataUrl && apercu) {
        apercu.innerHTML = `<img src="${dataUrl}" style="width:120px;border-radius:10px;">`;

        try {
          const file = dataURLToFile(dataUrl, `profil_${i}.png`);
          const dt = new DataTransfer();
          dt.items.add(file);
          if (input) input.files = dt.files;
        } catch (err) {
          console.warn("Impossible de recréer File pour profile_" + i, err);
        }
      }
    }
  })();

  const saved = JSON.parse(sessionStorage.getItem("formDataAutoSave") || "[]");
  if (saved.length > 0) {
    const allForms = document.querySelectorAll(".formulaire");
    saved.forEach((data, index) => {
      const form = allForms[index];
      if (!form) return;
      form.querySelectorAll("input").forEach(inp => {
        if (inp.type !== "file" && data[inp.name]) inp.value = data[inp.name];
      });
    });
  }

  // 🔄 Restauration des profils depuis IndexedDB
  const profilsSaved = await loadData("profilsDefinitifs") || [];
  const allForms = document.querySelectorAll(".formulaire");

  allForms.forEach((form, idx) => {
    if (profilsSaved[idx]) {
      const apercuDiv = document.getElementById("aperçu_" + (idx + 1));
      apercuDiv.innerHTML = `<img src="${profilsSaved[idx]}" style="width:120px;border-radius:10px;">`;
    }
  });

  /*****************************************************
   * 2️⃣ Retour de l’éditeur : insertion automatique de l’image
   *****************************************************/
  const imageFinale = sessionStorage.getItem("imageModifiee");
  const idInput = sessionStorage.getItem("inputActif");

  if (imageFinale && idInput) {
    const fileImage = dataURLToFile(imageFinale, "photo_modifiee.png");
    const dt = new DataTransfer();
    dt.items.add(fileImage);

    const input = document.getElementById(idInput);
    input.files = dt.files;

    const parentIndex = idInput.split("_")[1];
    const apercu = document.getElementById("aperçu_" + parentIndex);
    apercu.innerHTML = `<img src="${imageFinale}" style="width:120px;border-radius:10px;">`;

    let profils = await loadData("profilsDefinitifs") || [];
    profils[parentIndex - 1] = imageFinale;
    await saveData("profilsDefinitifs", profils);

    sessionStorage.removeItem("imageModifiee");
    sessionStorage.removeItem("imageOriginale");
    sessionStorage.removeItem("inputActif");

    alert("✅ Profil modifié inséré correctement !");
  }

  /*****************************************************
   * 3️⃣ Redirection vers l’éditeur lors du choix du profil
   *****************************************************/
  document.addEventListener("change", e => {
    if (e.target && e.target.type === "file" && e.target.id.startsWith("profile_")) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = ev => {
        sessionStorage.setItem("imageOriginale", ev.target.result);
        sessionStorage.setItem("inputActif", e.target.id);

        const nombreForms = parseInt(nombre) || document.querySelectorAll(".formulaire").length;
        const snap = [];
        for (let i = 1; i <= nombreForms; i++) {
          const ap = document.getElementById("aperçu_" + i);
          const prevSession = JSON.parse(sessionStorage.getItem('profilsModifies') || '[]')[i - 1];
          const prevLocal = profilsSaved[i - 1];
          snap[i - 1] = ap && ap.querySelector("img") ? ap.querySelector("img").src : prevSession || prevLocal || null;
        }
        sessionStorage.setItem("profilsModifies", JSON.stringify(snap));

        const forms = document.querySelectorAll(".formulaire");
        const sauvegarde = [];
        forms.forEach(form => {
          const data = {};
          form.querySelectorAll("input").forEach(inp => {
            if (inp.type !== "file") data[inp.name] = inp.value;
          });
          sauvegarde.push(data);
        });
        sessionStorage.setItem("formDataAutoSave", JSON.stringify(sauvegarde));

        window.location.href = "editeur.html";
      };
      reader.readAsDataURL(file);
    }
  });

  /*****************************************************
   * 4️⃣ Convertir DataURL → File
   *****************************************************/
  function dataURLToFile(dataurl, filename) {
    const arr = dataurl.split(",");
    const mime = arr[0].match(/:(.*?);/)[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) u8arr[n] = bstr.charCodeAt(n);
    return new File([u8arr], filename, { type: mime });
  }

  /*****************************************************
   * 5️⃣ Génération des cartes scolaires
   *****************************************************/
  document.getElementById("creerCartesBtn").addEventListener("click", async () => {
    const data = await loadData("allSpecimens") || [];
    if (data.length === 0) { alert("Aucun spécimen disponible !"); return; }

    let liste = "Choisis un spécimen :\n";
    data.forEach((sp, i) => liste += `${i + 1}. ${sp.nom}\n`);
    const choix = parseInt(prompt(liste)) - 1;
    if (choix < 0 || choix >= data.length) { alert("Choix invalide !"); return; }

    const specimen = data[choix];
    const forms = document.querySelectorAll(".formulaire");
    const formulaires = [];
    let pending = 0;

    forms.forEach((f, index) => {
      const formData = {};
      const inputs = f.querySelectorAll("input");

      inputs.forEach(inp => {
        if (inp.type === "file" && inp.files.length > 0) {
          pending++;
          const reader = new FileReader();
          reader.onload = e => {
            formData[inp.name] = e.target.result;
            let storedProfiles = JSON.parse(sessionStorage.getItem("profilsModifies") || "[]");
            storedProfiles[index] = e.target.result;
            sessionStorage.setItem("profilsModifies", JSON.stringify(storedProfiles));

            pending--;
            if (pending === 0) finalSave();
          };
          reader.readAsDataURL(inp.files[0]);
        } else {
          formData[inp.name] = inp.value;
        }
      });

      formulaires.push(formData);
    });

    async function finalSave() {
      await saveData("formulairesTemp", formulaires);
      await saveData("specimenChoisi", specimen);
      window.location.href = "generation.html";
    }
  });

  /*****************************************************
   * 🔄 Sauvegarde automatique de tous les champs
   *****************************************************/
  document.addEventListener("input", () => {
    const forms = document.querySelectorAll(".formulaire");
    const sauvegarde = [];
    forms.forEach(form => {
      const data = {};
      form.querySelectorAll("input").forEach(inp => {
        if (inp.type !== "file") data[inp.name] = inp.value;
      });
      sauvegarde.push(data);
    });
    sessionStorage.setItem("formDataAutoSave", JSON.stringify(sauvegarde));
  });

  document.getElementById("btnReset").addEventListener("click", async () => {
    if (confirm("Voulez-vous vraiment créer un nouveau formulaire ? Tous les profils et champs seront supprimés.")) {
      await saveData("profilsDefinitifs", []);
      sessionStorage.removeItem("profilsModifies");
      sessionStorage.removeItem("formDataAutoSave");
      await saveData("formulairesTemp", []);
      await saveData("nombreFormulaires", null);
      window.location.href = "index.html";
    }
  });

});