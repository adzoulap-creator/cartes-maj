function estNatif() {
    return !!(window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
}

// Appelle un plugin Capacitor sans import ni registerPlugin
function appelPlugin(plugin, methode, args) {
    const p = Capacitor.Plugins && Capacitor.Plugins[plugin];
    if (p && typeof p[methode] === 'function') {
        return p[methode](args);
    }
    if (typeof Capacitor.nativePromise === 'function') {
        return Capacitor.nativePromise(plugin, methode, args);
    }
    return Promise.reject(new Error("Plugin indisponible : " + plugin));
}

async function choisirImagesMobile() {
    const res = await appelPlugin('FilePicker', 'pickFiles', {
        types: ['image/*'],
        limit: 0,
        readData: true
    });
    return res.files.map(f => ({
        name: f.name,
        dataUrl: `data:${f.mimeType || 'image/jpeg'};base64,${f.data}`
    }));
}

async function enregistrerImage(dataUrl, nomFichier) {
    if (estNatif()) {
        const r = await appelPlugin('Filesystem', 'writeFile', {
            path: nomFichier,
            data: dataUrl.split(',')[1],
            directory: 'CACHE'
        });
        await appelPlugin('Share', 'share', {
            title: nomFichier,
            url: r.uri,
            dialogTitle: 'Enregistrer la carte'
        });
    } else {
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = nomFichier;
        document.body.appendChild(a);
        a.click();
        a.remove();
    }
}

async function enregistrerPlusieurs(liste) {
    if (estNatif()) {
        const uris = [];
        for (const it of liste) {
            const r = await appelPlugin('Filesystem', 'writeFile', {
                path: it.nom,
                data: it.dataUrl.split(',')[1],
                directory: 'CACHE'
            });
            uris.push(r.uri);
        }
        await appelPlugin('Share', 'share', {
            title: 'Cartes',
            files: uris,
            dialogTitle: 'Enregistrer les cartes'
        });
    } else {
        for (const it of liste) {
            await enregistrerImage(it.dataUrl, it.nom);
            await new Promise(r => setTimeout(r, 300));
        }
    }
}