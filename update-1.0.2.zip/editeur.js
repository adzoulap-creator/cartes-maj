// --- 3️⃣ Canvas et édition ---
const canvas = document.getElementById("canvasEditeur");
const ctx = canvas.getContext("2d");

let imageOriginale = sessionStorage.getItem("imageOriginale");
let luminosite = 100;
let cadreActuel = null;

const img = new Image();
img.onload = function () {
    const maxWidth = 350;
    if(img.width > maxWidth){
        canvas.width = maxWidth;
        canvas.height = img.height * (maxWidth / img.width);
    } else {
        canvas.width = img.width;
        canvas.height = img.height;
    }
    dessinerImage();
};
img.src = imageOriginale;

function dessinerImage() {
    const tmp = new Image();
    tmp.onload = function () {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.filter = `brightness(${luminosite}%)`;
        ctx.drawImage(tmp, 0, 0, canvas.width, canvas.height);

        if (cadreActuel) {
            const cadreImg = new Image();
            cadreImg.onload = () => ctx.drawImage(cadreImg, 0, 0, canvas.width, canvas.height);
            cadreImg.src = cadreActuel;
        }
    };
    tmp.src = imageOriginale;
}

// --- Menu gauche animation ---
window.addEventListener("load", () => {
    const menu = document.getElementById("menuGauche");
    setTimeout(() => menu.classList.add("active"), 300);
});

// --- Slider luminosité ---
const slider = document.getElementById("brightnessSlider");
slider.addEventListener("input", () => {
    luminosite = slider.value;
    dessinerImage();
});

function activerRecadrage() {
    // Supprime cropBox précédent si existant
    const oldCrop = document.getElementById("cropBox");
    if(oldCrop) oldCrop.remove();

    // Création du crop box
    let cropBox = document.createElement("div");
    cropBox.id = "cropBox";
    cropBox.style.position = "absolute";
    cropBox.style.border = "2px dashed red";
    cropBox.style.top = canvas.offsetTop + "px";
    cropBox.style.left = canvas.offsetLeft + "px";
    cropBox.style.width = canvas.width * 0.5 + "px";
    cropBox.style.height = canvas.height * 0.5 + "px";
    cropBox.style.cursor = "move";
    cropBox.style.zIndex = 1000;
    document.body.appendChild(cropBox);

    // Drag simple
    let isDragging = false, offsetX = 0, offsetY = 0;
    cropBox.addEventListener("pointerdown", e => {
        if (e.target.classList.contains("resizer")) return;
        isDragging = true;
        cropBox.setPointerCapture(e.pointerId);
        offsetX = e.clientX - cropBox.offsetLeft;
        offsetY = e.clientY - cropBox.offsetTop;
    });

    cropBox.addEventListener("pointermove", e => {
        if (!isDragging) return;
        cropBox.style.left = (e.clientX - offsetX) + "px";
        cropBox.style.top = (e.clientY - offsetY) + "px";
    });

    cropBox.addEventListener("pointerup", () => {
        isDragging = false;
    });
    document.addEventListener("mousemove", e => {
        if (!isDragging) return;
        cropBox.style.left = (e.clientX - offsetX) + "px";
        cropBox.style.top = (e.clientY - offsetY) + "px";
    });
    document.addEventListener("mouseup", () => { isDragging = false; });

    // --- Créer les coins resizables ---
    const resizers = ["top-left","top-right","bottom-left","bottom-right"];
    resizers.forEach(pos => {
        let res = document.createElement("div");
        res.className = "resizer " + pos;
        res.style.width = "10px";
        res.style.height = "10px";
        res.style.background = "red";
        res.style.position = "absolute";
        res.style.cursor = pos + "-resize";
        switch(pos){
            case "top-left": res.style.left="-5px"; res.style.top="-5px"; break;
            case "top-right": res.style.right="-5px"; res.style.top="-5px"; break;
            case "bottom-left": res.style.left="-5px"; res.style.bottom="-5px"; break;
            case "bottom-right": res.style.right="-5px"; res.style.bottom="-5px"; break;
        }
        cropBox.appendChild(res);

        // Redimensionner
        res.addEventListener("mousedown", e => {
            e.stopPropagation();
            let startX = e.clientX;
            let startY = e.clientY;
            let startWidth = parseInt(window.getComputedStyle(cropBox).width);
            let startHeight = parseInt(window.getComputedStyle(cropBox).height);
            let startLeft = parseInt(cropBox.style.left);
            let startTop = parseInt(cropBox.style.top);

            function onMouseMove(ev){
                let dx = ev.clientX - startX;
                let dy = ev.clientY - startY;
                if(pos.includes("right")) cropBox.style.width = startWidth + dx + "px";
                if(pos.includes("left")) {
                    cropBox.style.width = startWidth - dx + "px";
                    cropBox.style.left = startLeft + dx + "px";
                }
                if(pos.includes("bottom")) cropBox.style.height = startHeight + dy + "px";
                if(pos.includes("top")) {
                    cropBox.style.height = startHeight - dy + "px";
                    cropBox.style.top = startTop + dy + "px";
                }
            }
            function onMouseUp(){ 
                document.removeEventListener("mousemove", onMouseMove);
                document.removeEventListener("mouseup", onMouseUp);
            }
            document.addEventListener("mousemove", onMouseMove);
            document.addEventListener("mouseup", onMouseUp);
        });
    });

    // Bouton valider recadrage
    const validerBtn = document.createElement("button");
    validerBtn.textContent = "Valider recadrage";
    validerBtn.style.position = "absolute";
    validerBtn.style.top = (canvas.offsetTop + canvas.height + 10) + "px";
    validerBtn.style.left = canvas.offsetLeft + "px";
    validerBtn.style.zIndex = 1000;
    validerBtn.id = "validerRecadrageBtn";
    document.body.appendChild(validerBtn);

    validerBtn.addEventListener("click", () => {
        const cropX = parseInt(cropBox.style.left) - canvas.offsetLeft;
        const cropY = parseInt(cropBox.style.top) - canvas.offsetTop;
        const cropW = parseInt(cropBox.style.width);
        const cropH = parseInt(cropBox.style.height);

        const ratioX = img.width / canvas.width;
        const ratioY = img.height / canvas.height;

        const realCropX = cropX * ratioX;
        const realCropY = cropY * ratioY;
        const realCropW = cropW * ratioX;
        const realCropH = cropH * ratioY;

        const tempImg = new Image();
        tempImg.onload = function() {
            // Redimensionner le canvas et dessiner la partie recadrée
            canvas.width = realCropW;
            canvas.height = realCropH;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.filter = `brightness(${luminosite}%)`;
            ctx.drawImage(tempImg, realCropX, realCropY, realCropW, realCropH, 0, 0, realCropW, realCropH);
            // 🔥 IMPORTANT : mettre à jour l'image originale après recadrage
            imageOriginale = canvas.toDataURL("image/png");
            sessionStorage.setItem("imageOriginale", imageOriginale);
                        
            // Recharger l'image principale
            img.src = imageOriginale;

            // Supprimer cropBox et bouton
            cropBox.remove();
            validerBtn.remove();
        };
        tempImg.src = imageOriginale; // utilise l'image originale
        
    });

}
// --- Bouton Recadrer ---
document.getElementById("btnRecadrer").addEventListener("click", activerRecadrage);

// --- Modal cadres ---
function ouvrirModalCadres() { document.getElementById("modalCadres").style.display = "flex"; }
function fermerModalCadres() { document.getElementById("modalCadres").style.display = "none"; }
document.querySelectorAll(".cadreOption").forEach(img => {
    img.addEventListener("click", () => {
        cadreActuel = img.src;
        dessinerImage();
        fermerModalCadres();
    });
});
document.getElementById("btnCadres").addEventListener("click", ouvrirModalCadres);

// === Fonction pour dessiner le cadre sur le canvas ===
function drawCadreOnCanvas(finalCanvas, finalCtx, cadreSrc) {
    return new Promise((resolve) => {
        if (!cadreSrc) return resolve(); // aucun cadre
        const cadreImg = new Image();
        cadreImg.onload = () => {
            finalCtx.drawImage(cadreImg, 0, 0, finalCanvas.width, finalCanvas.height);
            resolve();
        };
        cadreImg.src = cadreSrc;
    });
}


// Bouton OK modifié
document.getElementById("btnOK").addEventListener("click", async () => {
    // Ici, canvas contient déjà l'image recadrée et la luminosité appliquée
    let finalCanvas = document.createElement("canvas");
    let finalCtx = finalCanvas.getContext("2d");

    finalCanvas.width = canvas.width;
    finalCanvas.height = canvas.height;

    finalCtx.filter = `brightness(${luminosite}%)`;
    finalCtx.drawImage(canvas, 0, 0);

    await drawCadreOnCanvas(finalCanvas, finalCtx, cadreActuel);
    await sauvegarderEtRediriger(finalCanvas);
});


// --- Fonction sauvegarder et rediriger avec IndexedDB ---
async function sauvegarderEtRediriger(finalCanvas) {
    await ouvrirDB();

    const dataUrl = finalCanvas.toDataURL("image/png");
    sessionStorage.setItem("imageModifiee", dataUrl);

    let indexInput = sessionStorage.getItem("inputActif").split("_")[1] - 1;

    let savedProfiles = JSON.parse(sessionStorage.getItem("profilsModifies") || "[]");
    savedProfiles[indexInput] = dataUrl;
    sessionStorage.setItem("profilsModifies", JSON.stringify(savedProfiles));

    // SAUVEGARDE PERMANENTE IndexedDB
    let profilsDef = await loadData("profilsDefinitifs") || [];
    profilsDef[indexInput] = dataUrl;
    await saveData("profilsDefinitifs", profilsDef);

    window.location.href = "formulaire.html";
}

// --- Bouton Annuler ---
document.getElementById("btnAnnuler").addEventListener("click", () => {
    window.location.href = "formulaire.html";
});