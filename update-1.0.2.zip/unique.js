// --- 3️⃣ Lancement UNIQUE ---
document.addEventListener("DOMContentLoaded", async () => {
    await ouvrirDB();          // ✅ une seule fois
    await afficherImage();     // ✅ affichage sûr
    initialiserEvenements();   // ✅ ton mécanisme
});

// --- 4️⃣ Tes événements (mécanisme conservé) ---
function initialiserEvenements() {

    document.getElementById("btnPlacer").addEventListener("click", () => {
        document.getElementById("checkbox").style.display = "block";
    });

    document.getElementById("btnAppliquer").addEventListener("click", () => {
        placer();
        document.getElementById("btnSauvegarder").style.display = "inline-block";
        document.getElementById("checkbox").style.display = "none";
    });

    document.getElementById("btnSauvegarder").addEventListener("click", () => {
        sauvegarder();
    });
}

// === Fonction placer() — INCHANGÉE ===
function placer() {
    const container = document.getElementById("imageContainer");
    const all = document.querySelectorAll("#checkbox input[type=checkbox]:checked");

    document.querySelectorAll("#imageContainer .champSpecimen").forEach(c => c.remove());

    all.forEach((ligne, index) => {
        const champ = document.createElement("div");
        champ.textContent = ligne.value;
        champ.className = "champSpecimen";
        champ.dataset.field = ligne.value;
        champ.style.left = "5%";
        champ.style.top = (10 + index * 10) + "%";

        container.appendChild(champ);
        makeDraggable(champ);
    });
}

// === Drag — INCHANGÉ ===
function makeDraggable(el) {
    let offsetX = 0, offsetY = 0, isDragging = false;

    el.addEventListener("mousedown", start);
    el.addEventListener("touchstart", start, { passive: false });

    function start(e) {
        e.preventDefault();
        isDragging = true;

        const point = e.touches ? e.touches[0] : e;
        offsetX = point.clientX - el.offsetLeft;
        offsetY = point.clientY - el.offsetTop;

        document.addEventListener("mousemove", move);
        document.addEventListener("mouseup", stop);
        document.addEventListener("touchmove", move, { passive: false });
        document.addEventListener("touchend", stop);
    }

    function move(e) {
        if (!isDragging) return;

        const parent = el.parentElement;
        const rect = parent.getBoundingClientRect();
        const point = e.touches ? e.touches[0] : e;

        el.style.left = ((point.clientX - offsetX) / rect.width) * 100 + "%";
        el.style.top = ((point.clientY - offsetY) / rect.height) * 100 + "%";
    }

    function stop() {
        isDragging = false;
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", stop);
        document.removeEventListener("touchmove", move);
        document.removeEventListener("touchend", stop);
    }
}

// === Sauvegarde — INCHANGÉE ===
async function sauvegarder() {
    const champs = document.querySelectorAll("#imageContainer .champSpecimen");

    const specimen = {
        id: Date.now(),
        nom: prompt("Entre un nom pour ce spécimen :"),
        imageSrc: await loadData("specimenImage"),
        champs: []
    };

    champs.forEach(c => {
        specimen.champs.push({
            text: c.textContent,
            left: c.style.left,
            top: c.style.top
        });
    });

    const all = await loadData("allSpecimens") || [];
    all.push(specimen);

    await saveData("allSpecimens", all);
    alert("Spécimen sauvegardé avec succès !");
}

// --- Affichage image (léger, sûr) ---
async function afficherImage() {
    const img = document.getElementById("imageInput");
    if (!img) return;

    const savedImg = await loadData("specimenImage");
    if (!savedImg) return;

    img.onload = () => {
        img.style.width = "400px";
        img.style.height = "600px";
        img.style.display = "block";
        img.style.margin = "auto";
        img.style.border = "2px solid black";
    };

    img.src = savedImg;
}