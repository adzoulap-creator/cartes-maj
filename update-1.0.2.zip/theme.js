(function () {
    function build() {
        if (document.querySelector(".bg-fx")) return;
        var fx = document.createElement("div");
        fx.className = "bg-fx";
        fx.setAttribute("aria-hidden", "true");
        var bubbles = [
            [6, 16, 15, 0],
            [20, 10, 19, 4],
            [34, 24, 13, 8],
            [50, 14, 21, 1.5],
            [64, 20, 16, 6],
            [78, 11, 18, 10],
            [90, 18, 14, 3]
        ];
        var html = "";
        bubbles.forEach(function (b) {
            html += '<span class="bubble" style="--x:' + b[0] + "%;--s:" + b[1] + "px;--d:" + b[2] + "s;--w:" + b[3] + 's"></span>';
        });
        html += '<div class="wave wave-3"></div><div class="wave wave-2"></div><div class="wave wave-1"></div>';
        fx.innerHTML = html;
        document.body.insertBefore(fx, document.body.firstChild);
    }

    if (document.body) build();
    else document.addEventListener("DOMContentLoaded", build);
})();
