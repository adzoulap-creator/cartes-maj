// Remplace TON-NOM par ton nom d'utilisateur GitHub
const URL_VERSION = "https://adzoulap-creator.github.io/cartes-maj/version.json";

// Indispensable : confirme que la version chargée démarre bien.
// Sans cet appel, le plugin annule la mise à jour au redémarrage suivant.
async function notifierPret() {
    if (!estNatif()) return;
    try {
        await appelPlugin('CapacitorUpdater', 'notifyAppReady', {});
    } catch (e) {
        console.warn("notifyAppReady :", e);
    }
}

async function verifierMiseAJour(manuel) {
    if (!estNatif()) {
        if (manuel) alert("Disponible uniquement dans l'application Android.");
        return;
    }
    try {
        const rep = await fetch(URL_VERSION + "?t=" + Date.now(), { cache: "no-store" });
        if (!rep.ok) throw new Error("Serveur de mise à jour inaccessible (" + rep.status + ")");
        const info = await rep.json();            // { version, url }

        const cur = await appelPlugin('CapacitorUpdater', 'current', {});
        const actuelle = (cur.bundle && cur.bundle.version) || "builtin";

        if (info.version === actuelle) {
            if (manuel) alert("✅ L'application est déjà à jour (" + actuelle + ").");
            return;
        }
        if (!confirm("Nouvelle version " + info.version + " disponible. Mettre à jour maintenant ?")) return;

        const bundle = await appelPlugin('CapacitorUpdater', 'download', {
            url: info.url,
            version: info.version
        });
        await appelPlugin('CapacitorUpdater', 'set', { id: bundle.id }); // recharge l'app
    } catch (e) {
        console.error(e);
        if (manuel) alert("❌ Mise à jour impossible : " + (e.message || e));
    }
}

document.addEventListener("DOMContentLoaded", () => {
    notifierPret();
    verifierMiseAJour(false);                     // vérification silencieuse au démarrage
    const btn = document.getElementById("updateBtn");
    if (btn) btn.addEventListener("click", () => verifierMiseAJour(true));
});