// capacitorUtils.js
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Capacitor } from '@capacitor/core';

export { Filesystem, Directory, Share, Capacitor };
